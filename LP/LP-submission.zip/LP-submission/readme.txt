CSE5707 Fall 2022
Linear Programming Tools
Samson Weiner and Chuanyu Xue

##########################

Cargo Problem

Solution
Total profit: 12151.57894736842

Cargo distribution
Distribute 0.000000 C1 to Front
Distribute 0.000000 C1 to Center
Distribute 0.000000 C1 to Back
Distribute 10.000000 C2 to Front
Distribute 0.000000 C2 to Center
Distribute 5.000000 C2 to Back
Distribute 0.000000 C3 to Front
Distribute 12.947368 C3 to Center
Distribute 3.000000 C3 to Back
Distribute 0.000000 C4 to Front
Distribute 3.052632 C4 to Center
Distribute 0.000000 C4 to Back

##########################

Production Problem

Solution
Total cost: 16054.5

Production Plan 
Each month i has 4 values a,b,c,d where
a is the total amount produced that month
b is what is produced for the month i
c is what is produced for the month i+1
d is what is produced for the month i+2

Month 0: 500 500.00 0.00 0.00
Month 1: 2000 2000.00 0.00 0.00
Month 2: 1000 0.00 1000.00 0.00
Month 3: 4110 4110.00 0.00 0.00
Month 4: 6000 6000.00 0.00 0.00
Month 5: 7504 6500.00 1004.16 0.00
Month 6: 8000 6106.30 1893.70 0.00
Month 7: 8000 6314.61 1685.39 0.00
Month 8: 8000 8000.00 0.00 0.00