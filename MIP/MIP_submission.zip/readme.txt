CSE5707 Fall 2022
Linear Programming Tools
Samson Weiner and Chuanyu Xue

##########################

1. Portfolio problem

Solution
Total revenue: 22.3 Million

Investment plan:
Buy 2 of Fund 1
Buy 1 of Fund 2
Buy 1 of Fund 3
Buy 2 of Fund 4
Buy 1 of Fund 5
Buy 2 of Fund 6
Buy 1 of Fund 7
No Fund 8

5.8 + 1.8 + 1.5 + 3.8 + 1.3 + 5.9 + 2.2 = 22.3

##########################

2. Fram problem

Solution
Solving result: Feasible

Distribution of cows:
Son 0: [17, 21, 29, 31, 34, 37, 59, 64, 77] 369
Son 1: [9, 15, 24, 35, 42, 51, 52, 66, 75] 369
Son 2: [1, 6, 7, 20, 49, 67, 68, 72, 79] 369
Son 3: [4, 13, 18, 26, 50, 54, 60, 70, 74] 369
Son 4: [5, 16, 22, 25, 40, 46, 63, 71, 81] 369
Son 5: [8, 19, 23, 33, 39, 53, 56, 58, 80] 369
Son 6: [12, 27, 36, 41, 43, 44, 47, 57, 62] 369
Son 7: [10, 14, 28, 32, 38, 45, 61, 65, 76] 369
Son 8: [2, 3, 11, 30, 48, 55, 69, 73, 78] 369